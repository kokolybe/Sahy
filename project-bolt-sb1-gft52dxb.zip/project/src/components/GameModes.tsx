import React from 'react';
import { Heart, Users } from 'lucide-react';
import { Button } from './ui/Button';

export const GameModes: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-4xl">
      <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
        <div className="flex items-center gap-3 mb-4">
          <Heart className="w-8 h-8 text-primary" />
          <h2 className="font-poppins text-2xl font-bold">Mode Couple</h2>
        </div>
        <p className="text-gray-600 mb-6 font-inter">
          Découvrez-vous mutuellement à travers des questions intimes et des défis romantiques.
        </p>
        <Button className="w-full">Commencer</Button>
      </div>

      <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
        <div className="flex items-center gap-3 mb-4">
          <Users className="w-8 h-8 text-secondary" />
          <h2 className="font-poppins text-2xl font-bold">Mode Amis</h2>
        </div>
        <p className="text-gray-600 mb-6 font-inter">
          Jouez jusqu'à 8 joueurs avec des quiz, action ou vérité, et des défis collectifs.
        </p>
        <Button variant="secondary" className="w-full">Commencer</Button>
      </div>
    </div>
  );
};